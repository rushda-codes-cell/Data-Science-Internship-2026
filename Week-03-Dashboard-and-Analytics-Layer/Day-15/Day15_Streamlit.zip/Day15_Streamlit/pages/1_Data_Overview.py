import streamlit as st

st.title("📁 Data Overview")
st.write("This page shows the dataset overview.")