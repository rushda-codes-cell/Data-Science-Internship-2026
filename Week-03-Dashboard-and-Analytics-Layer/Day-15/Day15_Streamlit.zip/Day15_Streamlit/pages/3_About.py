import streamlit as st

st.title("ℹ️ About")
st.write("This dashboard was created using Streamlit for Day 15.")