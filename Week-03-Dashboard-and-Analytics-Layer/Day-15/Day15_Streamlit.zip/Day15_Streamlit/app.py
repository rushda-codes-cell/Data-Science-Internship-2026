import streamlit as st

st.set_page_config(
    page_title="My Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("📊 My Streamlit Dashboard")

st.write("Welcome to my Day 15 Streamlit project!")
st.write("Use the sidebar to navigate between pages.")

st.header("📁 Data Overview")
st.write("This is the Data Overview page.")

st.header("📈 Visualizations")
st.write("Charts will be added here.")

st.header("ℹ️ About")
st.write("This dashboard was created using Streamlit.")