from __future__ import annotations

from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(page_title="RetailPulse", page_icon="📊", layout="wide")

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODEL_DIR = BASE_DIR / "models"


@st.cache_data(show_spinner=False)
def load_csv(filename: str, date_columns: tuple[str, ...] = ()) -> pd.DataFrame:
    path = DATA_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Missing required file: {path}")
    frame = pd.read_csv(path)
    for column in date_columns:
        if column in frame.columns:
            frame[column] = pd.to_datetime(frame[column], errors="coerce")
    return frame


@st.cache_data(show_spinner=False)
def load_excel(filename: str) -> pd.DataFrame:
    path = DATA_DIR / filename
    if not path.exists():
        raise FileNotFoundError(f"Missing required file: {path}")
    return pd.read_excel(path, engine="openpyxl")


@st.cache_data(show_spinner=False)
def load_all_data() -> dict[str, pd.DataFrame]:
    return {
        "hybrid": load_csv("hybrid_forecast_results.csv", ("Date",)),
        "prophet": load_csv("prophet_forecast.csv", ("ds",)),
        "inventory": load_csv("inventory_optimization_results.csv", ("Date",)),
        "churn": load_csv("customer_churn_predictions.csv", ("LastPurchase",)),
        "rfm": load_csv("rfm_features.csv"),
        "rolling": load_csv("rolling_statistics.csv", ("InvoiceDate",)),
        "what_if": load_excel("Demand_Forecast_WhatIf.xlsx"),
    }


def numeric(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    result = frame.copy()
    for column in columns:
        if column in result.columns:
            result[column] = pd.to_numeric(result[column], errors="coerce")
    return result


def csv_download(frame: pd.DataFrame, filename: str, label: str) -> None:
    st.download_button(
        label=label,
        data=frame.to_csv(index=False).encode("utf-8"),
        file_name=filename,
        mime="text/csv",
    )


try:
    data = load_all_data()
except Exception as exc:
    st.error(f"Application data could not be loaded: {exc}")
    st.info("Check that all files are inside the data folder with the names shown in README.md.")
    st.stop()

hybrid = numeric(data["hybrid"], ["Actual", "Prophet_Prediction", "LSTM_Prediction", "Hybrid_Prediction"])
prophet = numeric(data["prophet"], ["yhat", "yhat_lower", "yhat_upper", "trend"])
inventory = numeric(data["inventory"], ["Actual", "Hybrid_Prediction", "Safety_Stock", "Recommended_Inventory"])
churn = numeric(data["churn"], ["TotalOrders", "TotalQuantity", "TotalSpending", "Recency", "Churn", "ChurnPrediction", "ChurnProbability"])
rfm = numeric(data["rfm"], ["Recency", "Frequency", "Monetary", "R_Score", "F_Score", "M_Score", "RFM_Score"])
rolling = numeric(data["rolling"], ["SalesAmount", "RollingMean7", "RollingStd7"])
what_if = numeric(data["what_if"], ["Month", "Forecast", "Normal Demand", "High Demand", "Low Demand"])

st.sidebar.title("RetailPulse")
page = st.sidebar.radio(
    "Select dashboard",
    [
        "Overview",
        "Hybrid Forecast",
        "Prophet Forecast",
        "What-If Analysis",
        "Inventory Optimization",
        "Customer Churn",
        "RFM Segmentation",
        "Rolling Statistics",
    ],
)

st.title("RetailPulse Analytics Dashboard")
st.caption("Demand forecasting, inventory optimization and customer analytics")

if page == "Overview":
    st.header("Project Overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Forecast Days", f"{len(hybrid):,}")
    c2.metric("Customers", f"{len(churn):,}")
    c3.metric("Inventory Records", f"{len(inventory):,}")
    c4.metric("What-If Months", f"{len(what_if):,}")

    summary = pd.DataFrame(
        {
            "Dataset": ["Hybrid Forecast", "Prophet Forecast", "Inventory", "Customer Churn", "RFM", "Rolling Statistics", "What-If"],
            "Rows": [len(hybrid), len(prophet), len(inventory), len(churn), len(rfm), len(rolling), len(what_if)],
            "Columns": [hybrid.shape[1], prophet.shape[1], inventory.shape[1], churn.shape[1], rfm.shape[1], rolling.shape[1], what_if.shape[1]],
        }
    )
    st.dataframe(summary, use_container_width=True, hide_index=True)
    model_path = MODEL_DIR / "lstm_demand_model.pth"
    st.success("LSTM model file is included in the Docker project." if model_path.exists() else "LSTM model file is not present.")

elif page == "Hybrid Forecast":
    st.header("Hybrid Demand Forecast")
    chart = hybrid.dropna(subset=["Date"]).set_index("Date")[["Actual", "Prophet_Prediction", "LSTM_Prediction", "Hybrid_Prediction"]]
    st.line_chart(chart, use_container_width=True)
    if hybrid["Actual"].notna().any():
        error = (hybrid["Actual"] - hybrid["Hybrid_Prediction"]).abs()
        wape = error.sum() / hybrid["Actual"].abs().sum() * 100
        st.metric("Hybrid WAPE", f"{wape:.2f}%")
    st.dataframe(hybrid, use_container_width=True, hide_index=True)
    csv_download(hybrid, "hybrid_forecast_results.csv", "Download hybrid forecast")

elif page == "Prophet Forecast":
    st.header("Prophet Forecast")
    prophet_chart = prophet.dropna(subset=["ds"]).set_index("ds")[["yhat", "yhat_lower", "yhat_upper"]]
    st.line_chart(prophet_chart, use_container_width=True)
    st.dataframe(prophet[[c for c in ["ds", "trend", "yhat_lower", "yhat_upper", "yhat"] if c in prophet.columns]], use_container_width=True, hide_index=True)
    csv_download(prophet, "prophet_forecast.csv", "Download Prophet forecast")

elif page == "What-If Analysis":
    st.header("Demand Forecast What-If Analysis")
    scenarios = ["Normal Demand", "High Demand", "Low Demand"]
    scenario = st.selectbox("Display scenario", ["All Scenarios", *scenarios])
    indexed = what_if.dropna(subset=["Month"]).set_index("Month")
    st.line_chart(indexed[scenarios if scenario == "All Scenarios" else [scenario]], use_container_width=True)

    normal = what_if["Normal Demand"].mean()
    high = what_if["High Demand"].mean()
    low = what_if["Low Demand"].mean()
    c1, c2, c3 = st.columns(3)
    c1.metric("Average Normal", f"{normal:,.0f}")
    c2.metric("Average High", f"{high:,.0f}", f"{high-normal:,.0f}")
    c3.metric("Average Low", f"{low:,.0f}", f"{low-normal:,.0f}")

    display = what_if.copy()
    display["High Change %"] = ((display["High Demand"] / display["Normal Demand"]) - 1) * 100
    display["Low Change %"] = ((display["Low Demand"] / display["Normal Demand"]) - 1) * 100
    st.dataframe(display, use_container_width=True, hide_index=True)
    csv_download(display, "what_if_forecast.csv", "Download What-If results")

elif page == "Inventory Optimization":
    st.header("Inventory Optimization")
    c1, c2, c3 = st.columns(3)
    c1.metric("Recommended Inventory", f"{inventory['Recommended_Inventory'].sum():,.0f}")
    c2.metric("Average Safety Stock", f"{inventory['Safety_Stock'].mean():,.0f}")
    c3.metric("Records", f"{len(inventory):,}")
    status = inventory["Inventory_Status"].fillna("Unknown").value_counts()
    st.bar_chart(status)
    st.dataframe(inventory, use_container_width=True, hide_index=True)
    csv_download(inventory, "inventory_optimization_results.csv", "Download inventory results")

elif page == "Customer Churn":
    st.header("Customer Churn Analysis")
    predicted = int(churn["ChurnPrediction"].fillna(0).sum())
    rate = predicted / len(churn) * 100 if len(churn) else 0
    c1, c2, c3 = st.columns(3)
    c1.metric("Customers", f"{len(churn):,}")
    c2.metric("Predicted Churn", f"{predicted:,}")
    c3.metric("Churn Rate", f"{rate:.2f}%")
    threshold = st.slider("Minimum churn probability", 0.0, 1.0, 0.5, 0.05)
    filtered = churn[churn["ChurnProbability"] >= threshold].sort_values("ChurnProbability", ascending=False)
    st.dataframe(filtered, use_container_width=True, hide_index=True)
    csv_download(filtered, "filtered_churn_customers.csv", "Download filtered customers")

elif page == "RFM Segmentation":
    st.header("RFM Customer Segmentation")
    c1, c2, c3 = st.columns(3)
    c1.metric("Customers", f"{len(rfm):,}")
    c2.metric("Average Frequency", f"{rfm['Frequency'].mean():.2f}")
    c3.metric("Total Monetary Value", f"{rfm['Monetary'].sum():,.2f}")
    score_counts = rfm["RFM_Score"].astype("Int64").astype(str).value_counts().head(15)
    st.bar_chart(score_counts)
    st.dataframe(rfm.sort_values("Monetary", ascending=False), use_container_width=True, hide_index=True)
    csv_download(rfm, "rfm_features.csv", "Download RFM data")

elif page == "Rolling Statistics":
    st.header("Seven-Day Rolling Sales Statistics")
    chart = rolling.dropna(subset=["InvoiceDate"]).set_index("InvoiceDate")[["SalesAmount", "RollingMean7"]]
    st.line_chart(chart, use_container_width=True)
    st.dataframe(rolling, use_container_width=True, hide_index=True)
    csv_download(rolling, "rolling_statistics.csv", "Download rolling statistics")
