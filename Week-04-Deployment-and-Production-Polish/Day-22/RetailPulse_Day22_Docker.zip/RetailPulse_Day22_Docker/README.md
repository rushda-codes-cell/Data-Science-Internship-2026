# RetailPulse Day 22 — Docker Multi-Stage Build

## Included data
- Hybrid demand forecast
- Prophet forecast
- Inventory optimization
- Customer churn predictions
- RFM features
- Rolling statistics
- Demand Forecast What-If workbook
- LSTM model artifact (included for project completeness; dashboard displays precomputed LSTM predictions)

## Run without Docker
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
Open http://localhost:8501

## Run with Docker
```bash
docker build -t retailpulse-app:day22 .
docker run -d --name retailpulse-container -p 8501:8501 retailpulse-app:day22
```
Open http://localhost:8501

## Useful commands
```bash
docker logs -f retailpulse-container
docker ps
docker stop retailpulse-container
docker rm -f retailpulse-container
```

After changing code, rebuild:
```bash
docker rm -f retailpulse-container
docker build --no-cache -t retailpulse-app:day22 .
docker run -d --name retailpulse-container -p 8501:8501 retailpulse-app:day22
```
