# Day 23 — Kubernetes Manifests and Deployment

## Included

- Namespace
- ConfigMap for Streamlit settings
- Deployment with 2 replicas and rolling updates
- Startup, readiness and liveness probes
- CPU and memory requests/limits
- NodePort Service on port 30501
- Horizontal Pod Autoscaler from 2 to 5 replicas
- Kustomization file

## Run with Minikube

```powershell
minikube start
docker build -t retailpulse-app:day23 .
minikube image load retailpulse-app:day23
minikube addons enable metrics-server
kubectl apply -k k8s
kubectl rollout status deployment/retailpulse -n retailpulse
kubectl get all -n retailpulse
minikube service retailpulse-service -n retailpulse
```

## Run with Docker Desktop Kubernetes

Enable Kubernetes in Docker Desktop, then run:

```powershell
docker build -t retailpulse-app:day23 .
kubectl apply -k k8s
kubectl rollout status deployment/retailpulse -n retailpulse
kubectl port-forward service/retailpulse-service 8501:8501 -n retailpulse
```

Open `http://localhost:8501`.

## Remote cluster or Docker Hub

Push your image:

```powershell
docker login
docker tag retailpulse-app:day23 YOUR_USERNAME/retailpulse-app:day23
docker push YOUR_USERNAME/retailpulse-app:day23
```

Then change this line in `k8s/deployment.yaml`:

```yaml
image: YOUR_USERNAME/retailpulse-app:day23
```

For a remote registry, also change `imagePullPolicy` to `Always`.

## Useful commands

```powershell
kubectl get pods -n retailpulse
kubectl get service -n retailpulse
kubectl get hpa -n retailpulse
kubectl logs deployment/retailpulse -n retailpulse
kubectl describe deployment retailpulse -n retailpulse
kubectl rollout restart deployment/retailpulse -n retailpulse
kubectl delete namespace retailpulse
```

## Common issue: ImagePullBackOff

For Minikube:

```powershell
minikube image load retailpulse-app:day23
kubectl rollout restart deployment/retailpulse -n retailpulse
```

For a remote cluster, push the image to a registry and update the Deployment image name.
